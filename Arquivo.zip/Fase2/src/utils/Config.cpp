#include "Config.h"
#include <iostream>

using namespace tinyxml2;

Config::Config() : width(800), height(800), fov(45.0f), near(1.0f), far(1000.0f), root(nullptr) {
    for(int i=0; i<3; i++) posCam[i] = lookAt[i] = up[i] = 0.0f;
}

Config::~Config() {
    delete root;
}

bool Config::loadXML(const char* xmlPath) {
    XMLDocument doc;
    if (doc.LoadFile(xmlPath) != XML_SUCCESS) return false;

    XMLElement* root = doc.FirstChildElement("world");
    if (!root) return false;

    // 1. Window
    XMLElement* win = root->FirstChildElement("window");
    if (win) {
        width = win->IntAttribute("width");
        height = win->IntAttribute("height");
    }

    // 2. Camera
    XMLElement* cam = root->FirstChildElement("camera");
    if (cam) {
        XMLElement* pos = cam->FirstChildElement("position");
        if (pos) {
            posCam[0] = pos->FloatAttribute("x");
            posCam[1] = pos->FloatAttribute("y");
            posCam[2] = pos->FloatAttribute("z");
        }

        XMLElement* la = cam->FirstChildElement("lookAt");
        if (la) {
            lookAt[0] = la->FloatAttribute("x");
            lookAt[1] = la->FloatAttribute("y");
            lookAt[2] = la->FloatAttribute("z");
        }

        XMLElement* u = cam->FirstChildElement("up");
        if (u) {
            up[0] = u->FloatAttribute("x");
            up[1] = u->FloatAttribute("y");
            up[2] = u->FloatAttribute("z");
        }

        XMLElement* proj = cam->FirstChildElement("projection");
        if (proj) {
            fov = proj->FloatAttribute("fov");
            near = proj->FloatAttribute("near");
            far = proj->FloatAttribute("far");
        }
    }

    // 3. Models
    XMLElement* g = root->FirstChildElement("group");
    if (!g){
        std::cout << "[Config] No <group> in <world>" << std::endl;
        return true; // cena vazia
    }

    this->root = new Group();
    std::cout << "[Config] Parsing root <group>" << std::endl;
    parseGroup(g, this->root);

    return true;
}


void Config::parseGroup(XMLElement* groupElement, Group* currentGroup) {
    std::cout << "[Config] New group at " << groupElement << std::endl;
    for (XMLElement* child = groupElement->FirstChildElement(); child; child = child->NextSiblingElement()) {
        std::string name = child->Value();
        std::cout << "  [Config] child node: " << name << std::endl;

        // 1. Transformações
        if (name == "transform") {
            for (XMLElement* t = child->FirstChildElement(); t; t = t->NextSiblingElement()) {
                std::string tName = t->Value();
                if (tName == "translate") {
                    currentGroup->transforms.push_back(
                        new Translate(t->FloatAttribute("x"), t->FloatAttribute("y"), t->FloatAttribute("z")));
                    }
                else if (tName == "rotate"){
                    currentGroup->transforms.push_back(
                        new Rotate(t->FloatAttribute("angle"), t->FloatAttribute("x"), t->FloatAttribute("y"), t->FloatAttribute("z")));
                    }
                else if (tName == "scale"){
                    currentGroup->transforms.push_back(
                        new Scale(t->FloatAttribute("x"), t->FloatAttribute("y"), t->FloatAttribute("z")));
                    }
            }
        }
        // 2. Modelos
        else if (name == "models") {
            for (XMLElement* m = child->FirstChildElement("model"); m; m = m->NextSiblingElement("model")) {
                const char* fname = m->Attribute("file");
                std::cout << "[Config] Loading model: " << (fname ? fname : "(null)") << std::endl;
                Figure f;
                if (fname && f.load(fname)) {
                    currentGroup->models.push_back(f);
                    std::cout << "[Config]   -> ok" << std::endl;
                } else {
                    std::cout << "[Config]   -> FAILED to load" << std::endl;
                }
            }
        }
        // 3. Subgrupos (Recursividade!) 
        else if (name == "group") {
            Group* newChild = new Group();
            currentGroup->children.push_back(newChild);
            parseGroup(child, newChild);
        }
    }
}